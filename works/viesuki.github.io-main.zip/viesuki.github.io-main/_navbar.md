<!-- _navbar.md -->

* <i class="fa fa-language"></i>语言

  * [:cn:中文](/)
  * [:us:English](/en/)
  * [:jp:日本語](/jp/)

* [<i class="fa fa-home"></i>主页](greeting/self_intro.md)
