- 前言
    * [简介](greeting/self_intro.md)
    * [关于网站](greeting/site.md)

- 点子
    * [怎样问个“好”问题](essays/problem_solve.md)
    * [网站资源合集](essays/websites.md)

- CS
    * [markdown](cs/markdown.md)
    * [网络爬虫(spider)](cs/spider.md)

- 日本語
    * [文法](jp_learning/bunpou.md)
    * [アニメについて](jp_learning/anime.md)



