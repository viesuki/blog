![logo](pic/logos.jpg)

## <i class="fa fa-mortar-board "></i>Viesuki_Note

> <small>旨在记录，也在分享，欢迎交流</small>

- Я тоже изучаю русский язык
- 毎日楽しく過ごすこと

<p id="sitetime"></p>

[<i class="fa fa-github "></i>GitHub](https://github.com/viesuki/)
[<i class="fa fa-toggle-right "></i>Get Started](greeting/self_intro.md)

<!--background pic-->
![](pic/backg-pic.svg)